using System;
#if UNITY_XR_ARKIT_LOADER_ENABLED && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif

namespace UnityEngine.XR.ARKit
{
    /// <summary>
    /// Information about an error condition including a domain, a domain-specific error code, and application-specific
    /// information.
    /// </summary>
    /// <remarks>
    /// This is a wrapper for Objective-C's
    /// [NSError](https://developer.apple.com/documentation/foundation/nserror?language=objc) object.
    /// </remarks>
    public struct NSError : INSObject, IEquatable<NSError>
    {
        IntPtr m_Self;

        /// <summary>
        /// Get the error code associated with this <see cref="NSError"/>.
        /// </summary>
        /// <remarks>
        /// Error codes are domain-specific. See <see cref="ToErrorDomain"/> and <see cref="domain"/>.
        ///
        /// Refer to [Apple's documentation](https://developer.apple.com/documentation/foundation/nserror/1409165-code?language=objc)
        /// for more information.
        /// </remarks>
        public long code => GetCode(this);

        /// <summary>
        /// Get a string containing the error domain.
        /// </summary>
        /// <remarks>
        /// Refer to [Apple's documentation](https://developer.apple.com/documentation/foundation/nserror/1413924-domain?language=objc)
        /// for more information.
        /// </remarks>
        /// <seealso cref="ToErrorDomain"/>
        public string domain => GetDomain(this).GetStringAndDispose();

        /// <summary>
        /// Get a string containing the localized description of the error.
        /// </summary>
        /// <remarks>
        /// Refer to [Apple's documentation](https://developer.apple.com/documentation/foundation/nserror/1414418-localizeddescription?language=objc)
        /// for more information.
        /// </remarks>
        public string localizedDescription => GetLocalizedDescription(this).GetStringAndDispose();

        /// <summary>
        /// Get a string containing the localized recovery suggestion for the error.
        /// </summary>
        /// <remarks>
        /// Refer to [Apple's documentation](https://developer.apple.com/documentation/foundation/nserror/1407500-localizedrecoverysuggestion?language=objc)
        /// for more information.
        /// </remarks>
        public string localizedRecoverySuggestion => GetLocalizedRecoverySuggestion(this).GetStringAndDispose();

        /// <summary>
        /// Get a string containing the localized explanation of the reason for the error.
        /// </summary>
        /// <remarks>
        /// Refer to [Apple's documentation](https://developer.apple.com/documentation/foundation/nserror/1412752-localizedfailurereason?language=objc)
        /// for more information.
        /// </remarks>
        public string localizedFailureReason => GetLocalizedFailureReason(this).GetStringAndDispose();

        /// <summary>
        /// Gets the underlying Objective-C pointer.
        /// </summary>
        /// <returns>The native pointer.</returns>
        public IntPtr AsIntPtr() => m_Self;

        /// <summary>
        /// Generates a string representation of this <see cref="NSError"/>.
        /// </summary>
        /// <remarks>
        /// This method uses
        /// [NSObject's description property](https://developer.apple.com/documentation/objectivec/1418956-nsobject/1418746-description)
        /// to generate the string.
        /// </remarks>
        /// <returns>A string representation of this <see cref="NSError"/>.</returns>
        public override string ToString() => NSObject.ToString(this);

        /// <summary>
        /// The <see cref="domain"/> as an <see cref="NSErrorDomain"/> enum.
        /// </summary>
        /// <remarks>
        /// This method tries to determine the error domain without generating any managed strings. If the error
        /// domain is <see cref="NSErrorDomain.Unknown"/>, you might still be able to get additional information from its
        /// string representation (<see cref="domain"/>).
        /// </remarks>
        /// <returns>Returns the <see cref="NSErrorDomain"/> of this <see cref="NSError"/>, or
        /// <see cref="NSErrorDomain.Unknown"/> if the error domain could not be determined.</returns>
        public NSErrorDomain ToErrorDomain()
        {
            using (var domain = GetDomain(this))
            {
                if (domain.Equals(ARErrorDomain))
                    return NSErrorDomain.ARKit;
                if (domain.Equals(CLErrorDomain))
                    return NSErrorDomain.CoreLocation;

                return NSErrorDomain.Unknown;
            }
        }

        /// <summary>
        /// Determines whether <paramref name="other"/> is equal to this one as determined by
        /// [isEqual:](https://developer.apple.com/documentation/objectivec/1418956-nsobject/1418795-isequal).
        /// </summary>
        /// <param name="other">The other <see cref="NSError"/> to test for equality.</param>
        /// <returns>Returns `true` if <paramref name="other"/> is considered equal using
        /// [isEqual:](https://developer.apple.com/documentation/objectivec/1418956-nsobject/1418795-isequal).
        /// Returns `false` otherwise.</returns>
        public bool Equals(NSError other) => NSObject.IsEqual(this, other);

        /// <summary>
        /// Tests for equality.
        /// </summary>
        /// <param name="obj">The <see cref="object"/> to test.</param>
        /// <returns>Returns `true` if <paramref name="obj"/> is an <see cref="NSError"/> and is considered equal using
        /// <see cref="Equals(UnityEngine.XR.ARKit.NSError)"/>. Returns `false` otherwise.</returns>
        public override bool Equals(object obj) => obj is NSError other && Equals(other);

        /// <summary>
        /// Generates a hash code for this <see cref="NSError"/>.
        /// </summary>
        /// <remarks>
        /// The hash code is generated using NSObject's
        /// [hash](https://developer.apple.com/documentation/objectivec/1418956-nsobject/1418859-hash) property.
        /// </remarks>
        /// <returns>A hash code for this instance.</returns>
        public override int GetHashCode() => NSObject.GetHashCode(this);

        /// <summary>
        /// Tests whether the underlying pointers for two <see cref="NSError"/> objects are the same.
        /// </summary>
        /// <remarks>
        /// This only tests whether two <see cref="NSError"/>s point to the same object in memory. Two different
        /// <see cref="NSError"/>s could still be considered equal. See
        /// <see cref="Equals(UnityEngine.XR.ARKit.NSError)"/>.
        /// </remarks>
        /// <param name="lhs">The instance to compare with <paramref name="rhs"/>.</param>
        /// <param name="rhs">The instance to compare with <paramref name="lhs"/>.</param>
        /// <returns><see langword="true"/> if the native pointers of <paramref name="lhs"/> and <paramref name="rhs"/>
        /// are equal. Otherwise, returns <see langword="false"/>.</returns>
        public static bool operator ==(NSError lhs, NSError rhs) => lhs.m_Self == rhs.m_Self;

        /// <summary>
        /// Tests whether the underlying pointers for two <see cref="NSError"/> objects are different.
        /// </summary>
        /// <remarks>
        /// This only tests whether two <see cref="NSError"/>s point to different objects in memory. Two different
        /// <see cref="NSError"/>s could still be considered equal. See
        /// <see cref="Equals(UnityEngine.XR.ARKit.NSError)"/>.
        /// </remarks>
        /// <param name="lhs">The instance to compare with <paramref name="rhs"/>.</param>
        /// <param name="rhs">The instance to compare with <paramref name="lhs"/>.</param>
        /// <returns><see langword="false"/> if the native pointers of <paramref name="lhs"/> and <paramref name="rhs"/>
        /// are equal. Otherwise, returns <see langword="true"/>.</returns>
        public static bool operator !=(NSError lhs, NSError rhs) => lhs.m_Self != rhs.m_Self;

        /// <summary>
        /// Tests for equality.
        /// </summary>
        /// <remarks>
        /// This equality operator allows you to compare an instance with <see langword="null"/> to determine whether its
        /// native pointer is `null`.
        /// </remarks>
        /// <example>
        /// <code>
        /// void TestForNull(NSError error)
        /// {
        ///     // True if the native NSError object is null.
        ///     if (error == null)
        ///     {
        ///         // Do something with the error
        ///     }
        /// }
        /// </code>
        /// </example>
        /// <param name="lhs">The nullable `NSError` to compare with <paramref name="rhs"/>.</param>
        /// <param name="rhs">The nullable `NSError` to compare with <paramref name="lhs"/>.</param>
        /// <returns><see langword="true"/> if any of these conditions are met:
        /// - <paramref name="lhs"/> and <paramref name="rhs"/> are both not `null` and their native pointers are equal.
        /// - <paramref name="lhs"/> is `null` and <paramref name="rhs"/>'s native pointer is `null`.
        /// - <paramref name="rhs"/> is `null` and <paramref name="lhs"/>'s native pointer is `null`.
        /// - Both <paramref name="lhs"/> and <paramref name="rhs"/> are `null`.
        ///
        /// Otherwise, returns <see langword="false"/>
        /// </returns>
        public static bool operator ==(NSError? lhs, NSError? rhs) => NSObject.ArePointersEqual(lhs, rhs);

        /// <summary>
        /// Tests for inequality.
        /// </summary>
        /// <param name="lhs">The nullable `NSError` to compare with <paramref name="rhs"/>.</param>
        /// <param name="rhs">The nullable `NSError` to compare with <paramref name="lhs"/>.</param>
        /// <returns>The negation of <see cref="operator==(NSError?,NSError?)"/>.</returns>
        public static bool operator !=(NSError? lhs, NSError? rhs) => !(lhs == rhs);

        /// <inheritdoc cref="INSObject.SetUnderlyingNativePtr"/>
        void INSObject.SetUnderlyingNativePtr(IntPtr ptr) => m_Self = ptr;

        /// <inheritdoc cref="INSObject.staticClass"/>
        Class INSObject.staticClass => GetClass();

        internal void Dispose() => NSObject.Dispose(ref m_Self);

#if UNITY_EDITOR || !UNITY_XR_ARKIT_LOADER_ENABLED
        static long GetCode(NSError self) => default;

        static NSString GetDomain(NSError self) => default;

        static NSString GetLocalizedDescription(NSError self) => default;

        static NSString GetLocalizedRecoverySuggestion(NSError self) => default;

        static NSString GetLocalizedFailureReason(NSError self) => default;

        static NSString ARErrorDomain => default;

        static NSString CLErrorDomain => default;

        static Class GetClass() => default;
#else
        [DllImport("__Internal", EntryPoint = "NSError_get_code")]
        static extern long GetCode(NSError self);

        [DllImport("__Internal", EntryPoint = "NSError_get_domain")]
        static extern NSString GetDomain(NSError self);

        [DllImport("__Internal", EntryPoint = "NSError_get_localizedDescription")]
        static extern NSString GetLocalizedDescription(NSError self);

        [DllImport("__Internal", EntryPoint = "NSError_get_localizedRecoverySuggestion")]
        static extern NSString GetLocalizedRecoverySuggestion(NSError self);

        [DllImport("__Internal", EntryPoint = "NSError_get_localizedFailureReason")]
        static extern NSString GetLocalizedFailureReason(NSError self);

        static extern NSString ARErrorDomain
        {
            [DllImport("__Internal", EntryPoint = "UnityARKit_GetARErrorDomain")]
            get;
        }

        static extern NSString CLErrorDomain
        {
            [DllImport("__Internal", EntryPoint = "UnityARKit_GetCLErrorDomain")]
            get;
        }

        [DllImport("__Internal", EntryPoint = "NSError_class")]
        static extern Class GetClass();
#endif
    }
}
